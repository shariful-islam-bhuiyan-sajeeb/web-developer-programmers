import React from 'react';

const FAQ = () => {
    return (
        <div>
          <h2>This is FAQ page.</h2>   
        </div>
    );
};

export default FAQ; <h2>this is faq page.</h2>