import React from 'react';

const Blog = () => {
    return (
        <div>
            <h1>This is Blog page.</h1>  
        </div>
    );
};

export default Blog;  <h1>This is Blog page.</h1>